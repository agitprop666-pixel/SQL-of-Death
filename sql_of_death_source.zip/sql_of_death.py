"""
SQL Manager - Death's Head Software
A comprehensive SQL database management tool with dark theme
Supports MySQL, PostgreSQL, and SQLite
"""

from __future__ import annotations

import sys
import json
import sqlite3
from pathlib import Path
from typing import Optional, Dict, Any, List

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt6.QtGui import QIcon, QFont, QColor, QPalette, QTextCharFormat, QSyntaxHighlighter, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QLineEdit, QTextEdit, QTableWidget,
    QTableWidgetItem, QComboBox, QSpinBox, QMessageBox, QFileDialog,
    QSplitter, QTabWidget, QGroupBox, QCheckBox, QProgressBar,
    QHeaderView, QMenu, QDialog, QDialogButtonBox, QSplashScreen
)

# Optional imports for MySQL and PostgreSQL
try:
    import pymysql
    MYSQL_AVAILABLE = True
except ImportError:
    MYSQL_AVAILABLE = False

try:
    import psycopg2
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False

# =============================================================================
# Constants
# =============================================================================

APP_NAME = "SQL of Death"
ORG_NAME = "Death's Head Software"
VERSION = "1.0.0"

DARK_THEME = """
QMainWindow, QDialog {
    background-color: #1a1a1a;
    color: #e0e0e0;
}
QWidget {
    background-color: #1a1a1a;
    color: #e0e0e0;
}
QPushButton {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: 2px solid #444;
    border-radius: 5px;
    padding: 8px 16px;
    font-weight: bold;
}
QPushButton:hover {
    background-color: #3d3d3d;
    border-color: #666;
}
QPushButton:pressed {
    background-color: #1d1d1d;
}
QPushButton:disabled {
    background-color: #222;
    color: #666;
    border-color: #333;
}
QLineEdit, QTextEdit, QSpinBox, QComboBox {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: 2px solid #444;
    border-radius: 4px;
    padding: 6px;
}
QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QComboBox:focus {
    border-color: #666;
}
QTableWidget {
    background-color: #2d2d2d;
    color: #e0e0e0;
    gridline-color: #444;
    border: 2px solid #444;
}
QTableWidget::item {
    padding: 4px;
}
QTableWidget::item:selected {
    background-color: #4d4d4d;
}
QHeaderView::section {
    background-color: #1a1a1a;
    color: #e0e0e0;
    border: 1px solid #444;
    padding: 6px;
    font-weight: bold;
}
QTabWidget::pane {
    border: 2px solid #444;
    background-color: #1a1a1a;
}
QTabBar::tab {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: 2px solid #444;
    border-bottom: none;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    padding: 8px 16px;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: #1a1a1a;
    border-color: #666;
}
QTabBar::tab:hover {
    background-color: #3d3d3d;
}
QGroupBox {
    border: 2px solid #444;
    border-radius: 5px;
    margin-top: 12px;
    font-weight: bold;
    color: #e0e0e0;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 5px;
}
QLabel {
    color: #e0e0e0;
}
QCheckBox {
    color: #e0e0e0;
}
QProgressBar {
    border: 2px solid #444;
    border-radius: 4px;
    background-color: #2d2d2d;
    text-align: center;
    color: #e0e0e0;
}
QProgressBar::chunk {
    background-color: #4d4d4d;
}
QMenuBar {
    background-color: #1a1a1a;
    color: #e0e0e0;
}
QMenuBar::item:selected {
    background-color: #2d2d2d;
}
QMenu {
    background-color: #2d2d2d;
    color: #e0e0e0;
    border: 2px solid #444;
}
QMenu::item:selected {
    background-color: #3d3d3d;
}
QComboBox QAbstractItemView {
    background-color: #2d2d2d;
    color: #e0e0e0;
    selection-background-color: #4d4d4d;
    border: 2px solid #444;
}
"""

# =============================================================================
# Splash Screen
# =============================================================================

def create_splash():
    """
    Creates the QSplashScreen.

    It first checks for an external 'splash.png'. If not found, it generates
    a dark screen with the app name, org name, and ASCII skull art.
    """
    try:
        # Check for external splash.png
        splash_path = Path(__file__).parent / "splash.png"
        
        if splash_path.exists():
            # Load splash.png file
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                       Qt.TransformationMode.SmoothTransformation)
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 100); footer_rect.setBottom(pixmap.height() - 50)
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            # Fallback: Generate the dark-themed screen with ASCII art skull
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            text_rect = pixmap.rect(); text_rect.setTop(40); text_rect.setBottom(100)
            painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull_art = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            y_start = 250
            for i, line in enumerate(skull_art): 
                painter.drawText(250, y_start + (i * 25), line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            footer_rect = pixmap.rect(); footer_rect.setTop(pixmap.height() - 50); footer_rect.setBottom(pixmap.height())
            painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# SQL Syntax Highlighter
# =============================================================================

class SQLHighlighter(QSyntaxHighlighter):
    """Syntax highlighter for SQL queries"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        # Define formats
        self.keyword_format = QTextCharFormat()
        self.keyword_format.setForeground(QColor("#569cd6"))
        self.keyword_format.setFontWeight(QFont.Weight.Bold)
        
        self.string_format = QTextCharFormat()
        self.string_format.setForeground(QColor("#ce9178"))
        
        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor("#6a9955"))
        
        self.function_format = QTextCharFormat()
        self.function_format.setForeground(QColor("#dcdcaa"))
        
        # SQL keywords
        keywords = [
            'SELECT', 'FROM', 'WHERE', 'INSERT', 'UPDATE', 'DELETE', 'CREATE',
            'DROP', 'ALTER', 'TABLE', 'DATABASE', 'INDEX', 'VIEW', 'PROCEDURE',
            'FUNCTION', 'TRIGGER', 'JOIN', 'INNER', 'LEFT', 'RIGHT', 'OUTER',
            'ON', 'AND', 'OR', 'NOT', 'NULL', 'IS', 'AS', 'IN', 'BETWEEN',
            'LIKE', 'ORDER', 'BY', 'GROUP', 'HAVING', 'LIMIT', 'OFFSET',
            'DISTINCT', 'COUNT', 'SUM', 'AVG', 'MAX', 'MIN', 'PRIMARY', 'KEY',
            'FOREIGN', 'REFERENCES', 'UNIQUE', 'CHECK', 'DEFAULT', 'AUTO_INCREMENT',
            'INT', 'VARCHAR', 'TEXT', 'DATE', 'DATETIME', 'TIMESTAMP', 'BOOLEAN',
            'FLOAT', 'DOUBLE', 'DECIMAL', 'CHAR', 'BLOB', 'COMMIT', 'ROLLBACK',
            'TRANSACTION', 'BEGIN', 'END', 'IF', 'ELSE', 'CASE', 'WHEN', 'THEN',
            'USE', 'SHOW', 'TABLES', 'DATABASES', 'DESCRIBE', 'DESC', 'ASC'
        ]
        
        self.keywords = [f"\\b{kw}\\b" for kw in keywords]
    
    def highlightBlock(self, text):
        # Highlight keywords
        for pattern in self.keywords:
            import re
            for match in re.finditer(pattern, text, re.IGNORECASE):
                self.setFormat(match.start(), match.end() - match.start(), self.keyword_format)
        
        # Highlight strings
        import re
        for match in re.finditer(r"'[^']*'", text):
            self.setFormat(match.start(), match.end() - match.start(), self.string_format)
        for match in re.finditer(r'"[^"]*"', text):
            self.setFormat(match.start(), match.end() - match.start(), self.string_format)
        
        # Highlight comments
        for match in re.finditer(r"--[^\n]*", text):
            self.setFormat(match.start(), match.end() - match.start(), self.comment_format)

# =============================================================================
# Database Worker Thread
# =============================================================================

class DatabaseWorker(QThread):
    """Worker thread for database operations"""
    finished = pyqtSignal(object)  # Results or None
    error = pyqtSignal(str)
    
    def __init__(self, operation, *args, **kwargs):
        super().__init__()
        self.operation = operation
        self.args = args
        self.kwargs = kwargs
        self.connection = None
    
    def run(self):
        try:
            result = self.operation(*self.args, **self.kwargs)
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))

# =============================================================================
# Connection Dialog
# =============================================================================

class ConnectionDialog(QDialog):
    """Dialog for managing database connections"""
    
    def __init__(self, parent=None, connection_data=None):
        super().__init__(parent)
        self.setWindowTitle("Database Connection")
        self.resize(500, 400)
        
        self.connection_data = connection_data or {}
        
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Database type
        type_layout = QHBoxLayout()
        type_layout.addWidget(QLabel("Database Type:"))
        self.db_type = QComboBox()
        self.db_type.addItems(["SQLite", "MySQL", "PostgreSQL"])
        self.db_type.currentTextChanged.connect(self.on_type_changed)
        type_layout.addWidget(self.db_type)
        layout.addLayout(type_layout)
        
        # Connection name
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Connection Name:"))
        self.conn_name = QLineEdit()
        name_layout.addWidget(self.conn_name)
        layout.addLayout(name_layout)
        
        # SQLite file path
        self.sqlite_group = QGroupBox("SQLite Database")
        sqlite_layout = QVBoxLayout()
        file_layout = QHBoxLayout()
        file_layout.addWidget(QLabel("Database File:"))
        self.db_file = QLineEdit()
        file_layout.addWidget(self.db_file)
        browse_btn = QPushButton("Browse")
        browse_btn.clicked.connect(self.browse_file)
        file_layout.addWidget(browse_btn)
        sqlite_layout.addLayout(file_layout)
        self.sqlite_group.setLayout(sqlite_layout)
        layout.addWidget(self.sqlite_group)
        
        # MySQL/PostgreSQL settings
        self.server_group = QGroupBox("Server Connection")
        server_layout = QVBoxLayout()
        
        host_layout = QHBoxLayout()
        host_layout.addWidget(QLabel("Host:"))
        self.host = QLineEdit("localhost")
        host_layout.addWidget(self.host)
        server_layout.addLayout(host_layout)
        
        port_layout = QHBoxLayout()
        port_layout.addWidget(QLabel("Port:"))
        self.port = QSpinBox()
        self.port.setRange(1, 65535)
        self.port.setValue(3306)
        port_layout.addWidget(self.port)
        server_layout.addLayout(port_layout)
        
        db_layout = QHBoxLayout()
        db_layout.addWidget(QLabel("Database:"))
        self.database = QLineEdit()
        db_layout.addWidget(self.database)
        server_layout.addLayout(db_layout)
        
        user_layout = QHBoxLayout()
        user_layout.addWidget(QLabel("Username:"))
        self.username = QLineEdit()
        user_layout.addWidget(self.username)
        server_layout.addLayout(user_layout)
        
        pass_layout = QHBoxLayout()
        pass_layout.addWidget(QLabel("Password:"))
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.EchoMode.Password)
        pass_layout.addWidget(self.password)
        server_layout.addLayout(pass_layout)
        
        self.server_group.setLayout(server_layout)
        layout.addWidget(self.server_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        test_btn = QPushButton("Test Connection")
        test_btn.clicked.connect(self.test_connection)
        button_layout.addWidget(test_btn)
        
        self.button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)
        button_layout.addWidget(self.button_box)
        
        layout.addLayout(button_layout)
        
        # Load existing connection data
        if self.connection_data:
            self.load_connection_data()
        
        self.on_type_changed(self.db_type.currentText())
    
    def on_type_changed(self, db_type):
        """Update UI based on selected database type"""
        is_sqlite = db_type == "SQLite"
        self.sqlite_group.setVisible(is_sqlite)
        self.server_group.setVisible(not is_sqlite)
        
        if db_type == "MySQL":
            self.port.setValue(3306)
        elif db_type == "PostgreSQL":
            self.port.setValue(5432)
    
    def browse_file(self):
        """Browse for SQLite database file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select SQLite Database", "", "SQLite Database (*.db *.sqlite *.sqlite3);;All Files (*)"
        )
        if file_path:
            self.db_file.setText(file_path)
    
    def test_connection(self):
        """Test the database connection"""
        try:
            db_type = self.db_type.currentText()
            
            if db_type == "SQLite":
                db_path = self.db_file.text()
                if not db_path:
                    QMessageBox.warning(self, "Error", "Please specify a database file")
                    return
                conn = sqlite3.connect(db_path)
                conn.close()
            
            elif db_type == "MySQL":
                if not MYSQL_AVAILABLE:
                    QMessageBox.warning(self, "Error", "PyMySQL is not installed. Run: pip install pymysql")
                    return
                conn = pymysql.connect(
                    host=self.host.text(),
                    port=self.port.value(),
                    user=self.username.text(),
                    password=self.password.text(),
                    database=self.database.text()
                )
                conn.close()
            
            elif db_type == "PostgreSQL":
                if not POSTGRES_AVAILABLE:
                    QMessageBox.warning(self, "Error", "psycopg2 is not installed. Run: pip install psycopg2-binary")
                    return
                conn = psycopg2.connect(
                    host=self.host.text(),
                    port=self.port.value(),
                    user=self.username.text(),
                    password=self.password.text(),
                    database=self.database.text()
                )
                conn.close()
            
            QMessageBox.information(self, "Success", "Connection successful!")
        
        except Exception as e:
            QMessageBox.critical(self, "Connection Error", f"Failed to connect:\n{str(e)}")
    
    def load_connection_data(self):
        """Load connection data into form"""
        self.db_type.setCurrentText(self.connection_data.get('type', 'SQLite'))
        self.conn_name.setText(self.connection_data.get('name', ''))
        self.db_file.setText(self.connection_data.get('file', ''))
        self.host.setText(self.connection_data.get('host', 'localhost'))
        self.port.setValue(self.connection_data.get('port', 3306))
        self.database.setText(self.connection_data.get('database', ''))
        self.username.setText(self.connection_data.get('username', ''))
        self.password.setText(self.connection_data.get('password', ''))
    
    def get_connection_data(self):
        """Return connection data as dictionary"""
        data = {
            'type': self.db_type.currentText(),
            'name': self.conn_name.text() or f"{self.db_type.currentText()} Connection"
        }
        
        if data['type'] == 'SQLite':
            data['file'] = self.db_file.text()
        else:
            data['host'] = self.host.text()
            data['port'] = self.port.value()
            data['database'] = self.database.text()
            data['username'] = self.username.text()
            data['password'] = self.password.text()
        
        return data

# =============================================================================
# Main Application Window
# =============================================================================

class SQLManagerWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} v{VERSION}")
        self.setGeometry(100, 100, 1200, 800)
        
        # Set icon if available
        icon_path = Path(__file__).parent / "icon.ico"
        if icon_path.exists():
            self.setWindowIcon(QIcon(str(icon_path)))
        
        # Connection management
        self.current_connection = None
        self.connections = self.load_connections()
        
        # Initialize UI
        self.init_ui()
        
        # Apply dark theme
        self.setStyleSheet(DARK_THEME)
    
    def init_ui(self):
        """Initialize the user interface"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Header with skull ASCII art
        header = QLabel(f"💀 {APP_NAME} 💀")
        header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        header.setFont(QFont("Courier", 16, QFont.Weight.Bold))
        main_layout.addWidget(header)
        
        # Connection toolbar
        conn_layout = QHBoxLayout()
        conn_layout.addWidget(QLabel("Connection:"))
        
        self.connection_combo = QComboBox()
        self.update_connection_combo()
        self.connection_combo.currentTextChanged.connect(self.on_connection_changed)
        conn_layout.addWidget(self.connection_combo, 1)
        
        new_conn_btn = QPushButton("New")
        new_conn_btn.clicked.connect(self.new_connection)
        conn_layout.addWidget(new_conn_btn)
        
        edit_conn_btn = QPushButton("Edit")
        edit_conn_btn.clicked.connect(self.edit_connection)
        conn_layout.addWidget(edit_conn_btn)
        
        del_conn_btn = QPushButton("Delete")
        del_conn_btn.clicked.connect(self.delete_connection)
        conn_layout.addWidget(del_conn_btn)
        
        self.connect_btn = QPushButton("Connect")
        self.connect_btn.clicked.connect(self.connect_database)
        conn_layout.addWidget(self.connect_btn)
        
        self.disconnect_btn = QPushButton("Disconnect")
        self.disconnect_btn.clicked.connect(self.disconnect_database)
        self.disconnect_btn.setEnabled(False)
        conn_layout.addWidget(self.disconnect_btn)
        
        main_layout.addLayout(conn_layout)
        
        # Status label
        self.status_label = QLabel("Not connected")
        self.status_label.setStyleSheet("color: #ff6b6b; font-weight: bold;")
        main_layout.addWidget(self.status_label)
        
        # Main splitter
        splitter = QSplitter(Qt.Orientation.Horizontal)
        
        # Left panel - Database structure
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.addWidget(QLabel("Database Structure:"))
        
        self.table_list = QTableWidget(0, 1)
        self.table_list.setHorizontalHeaderLabels(["Tables"])
        self.table_list.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table_list.cellDoubleClicked.connect(self.on_table_selected)
        left_layout.addWidget(self.table_list)
        
        refresh_btn = QPushButton("Refresh Tables")
        refresh_btn.clicked.connect(self.refresh_tables)
        left_layout.addWidget(refresh_btn)
        
        splitter.addWidget(left_panel)
        
        # Right panel - Tabs
        self.tabs = QTabWidget()
        
        # Query tab
        query_widget = QWidget()
        query_layout = QVBoxLayout(query_widget)
        
        query_layout.addWidget(QLabel("SQL Query:"))
        self.query_edit = QTextEdit()
        self.query_edit.setFont(QFont("Courier", 10))
        self.query_edit.setPlaceholderText("Enter your SQL query here...")
        self.highlighter = SQLHighlighter(self.query_edit.document())
        query_layout.addWidget(self.query_edit)
        
        query_btn_layout = QHBoxLayout()
        execute_btn = QPushButton("Execute")
        execute_btn.clicked.connect(self.execute_query)
        query_btn_layout.addWidget(execute_btn)
        
        clear_btn = QPushButton("Clear")
        clear_btn.clicked.connect(self.query_edit.clear)
        query_btn_layout.addWidget(clear_btn)
        
        query_btn_layout.addStretch()
        query_layout.addLayout(query_btn_layout)
        
        self.tabs.addTab(query_widget, "Query")
        
        # Results tab
        results_widget = QWidget()
        results_layout = QVBoxLayout(results_widget)
        
        results_layout.addWidget(QLabel("Query Results:"))
        self.results_table = QTableWidget()
        results_layout.addWidget(self.results_table)
        
        export_layout = QHBoxLayout()
        export_csv_btn = QPushButton("Export to CSV")
        export_csv_btn.clicked.connect(self.export_to_csv)
        export_layout.addWidget(export_csv_btn)
        export_layout.addStretch()
        results_layout.addLayout(export_layout)
        
        self.tabs.addTab(results_widget, "Results")
        
        # Table browser tab
        browser_widget = QWidget()
        browser_layout = QVBoxLayout(browser_widget)
        
        browser_layout.addWidget(QLabel("Table Data:"))
        self.browser_table = QTableWidget()
        browser_layout.addWidget(self.browser_table)
        
        self.tabs.addTab(browser_widget, "Table Browser")
        
        splitter.addWidget(self.tabs)
        splitter.setSizes([300, 900])
        
        main_layout.addWidget(splitter)
        
        # Footer
        footer = QLabel(f"© {ORG_NAME}")
        footer.setAlignment(Qt.AlignmentFlag.AlignCenter)
        footer.setStyleSheet("color: #666; font-style: italic;")
        main_layout.addWidget(footer)
    
    def load_connections(self):
        """Load saved connections"""
        config_file = Path.home() / ".sql_manager_connections.json"
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def save_connections(self):
        """Save connections to file"""
        config_file = Path.home() / ".sql_manager_connections.json"
        try:
            with open(config_file, 'w') as f:
                json.dump(self.connections, f, indent=2)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to save connections:\n{str(e)}")
    
    def update_connection_combo(self):
        """Update connection combobox"""
        current = self.connection_combo.currentText()
        self.connection_combo.clear()
        for conn in self.connections:
            self.connection_combo.addItem(conn['name'])
        
        if current:
            index = self.connection_combo.findText(current)
            if index >= 0:
                self.connection_combo.setCurrentIndex(index)
    
    def new_connection(self):
        """Create new database connection"""
        dialog = ConnectionDialog(self)
        if dialog.exec():
            conn_data = dialog.get_connection_data()
            self.connections.append(conn_data)
            self.save_connections()
            self.update_connection_combo()
            self.connection_combo.setCurrentText(conn_data['name'])
    
    def edit_connection(self):
        """Edit selected connection"""
        index = self.connection_combo.currentIndex()
        if index < 0:
            QMessageBox.warning(self, "Error", "No connection selected")
            return
        
        dialog = ConnectionDialog(self, self.connections[index])
        if dialog.exec():
            self.connections[index] = dialog.get_connection_data()
            self.save_connections()
            self.update_connection_combo()
    
    def delete_connection(self):
        """Delete selected connection"""
        index = self.connection_combo.currentIndex()
        if index < 0:
            QMessageBox.warning(self, "Error", "No connection selected")
            return
        
        reply = QMessageBox.question(
            self, "Confirm Delete",
            f"Delete connection '{self.connections[index]['name']}'?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            del self.connections[index]
            self.save_connections()
            self.update_connection_combo()
    
    def on_connection_changed(self, conn_name):
        """Handle connection selection change"""
        if self.current_connection:
            self.disconnect_database()
    
    def connect_database(self):
        """Connect to selected database"""
        index = self.connection_combo.currentIndex()
        if index < 0:
            QMessageBox.warning(self, "Error", "No connection selected")
            return
        
        conn_data = self.connections[index]
        
        try:
            if conn_data['type'] == 'SQLite':
                self.current_connection = sqlite3.connect(conn_data['file'])
            
            elif conn_data['type'] == 'MySQL':
                if not MYSQL_AVAILABLE:
                    QMessageBox.critical(self, "Error", "PyMySQL not installed. Run: pip install pymysql")
                    return
                self.current_connection = pymysql.connect(
                    host=conn_data['host'],
                    port=conn_data['port'],
                    user=conn_data['username'],
                    password=conn_data['password'],
                    database=conn_data['database']
                )
            
            elif conn_data['type'] == 'PostgreSQL':
                if not POSTGRES_AVAILABLE:
                    QMessageBox.critical(self, "Error", "psycopg2 not installed. Run: pip install psycopg2-binary")
                    return
                self.current_connection = psycopg2.connect(
                    host=conn_data['host'],
                    port=conn_data['port'],
                    user=conn_data['username'],
                    password=conn_data['password'],
                    database=conn_data['database']
                )
            
            self.status_label.setText(f"Connected to {conn_data['name']}")
            self.status_label.setStyleSheet("color: #51cf66; font-weight: bold;")
            self.connect_btn.setEnabled(False)
            self.disconnect_btn.setEnabled(True)
            self.refresh_tables()
        
        except Exception as e:
            QMessageBox.critical(self, "Connection Error", f"Failed to connect:\n{str(e)}")
    
    def disconnect_database(self):
        """Disconnect from database"""
        if self.current_connection:
            try:
                self.current_connection.close()
            except:
                pass
            self.current_connection = None
        
        self.status_label.setText("Not connected")
        self.status_label.setStyleSheet("color: #ff6b6b; font-weight: bold;")
        self.connect_btn.setEnabled(True)
        self.disconnect_btn.setEnabled(False)
        self.table_list.setRowCount(0)
    
    def refresh_tables(self):
        """Refresh table list"""
        if not self.current_connection:
            return
        
        try:
            cursor = self.current_connection.cursor()
            
            # Get table list based on database type
            index = self.connection_combo.currentIndex()
            db_type = self.connections[index]['type']
            
            if db_type == 'SQLite':
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            elif db_type == 'MySQL':
                cursor.execute("SHOW TABLES")
            elif db_type == 'PostgreSQL':
                cursor.execute("SELECT tablename FROM pg_tables WHERE schemaname='public'")
            
            tables = [row[0] for row in cursor.fetchall()]
            
            self.table_list.setRowCount(len(tables))
            for i, table in enumerate(tables):
                self.table_list.setItem(i, 0, QTableWidgetItem(table))
            
            cursor.close()
        
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to retrieve tables:\n{str(e)}")
    
    def on_table_selected(self, row, col):
        """Handle table selection"""
        table_name = self.table_list.item(row, 0).text()
        self.browse_table(table_name)
    
    def browse_table(self, table_name):
        """Browse table contents"""
        if not self.current_connection:
            return
        
        try:
            cursor = self.current_connection.cursor()
            cursor.execute(f"SELECT * FROM {table_name} LIMIT 1000")
            
            results = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description]
            
            self.browser_table.setRowCount(len(results))
            self.browser_table.setColumnCount(len(columns))
            self.browser_table.setHorizontalHeaderLabels(columns)
            
            for i, row in enumerate(results):
                for j, value in enumerate(row):
                    self.browser_table.setItem(i, j, QTableWidgetItem(str(value)))
            
            self.browser_table.resizeColumnsToContents()
            self.tabs.setCurrentIndex(2)  # Switch to Table Browser tab
            
            cursor.close()
        
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to browse table:\n{str(e)}")
    
    def execute_query(self):
        """Execute SQL query"""
        if not self.current_connection:
            QMessageBox.warning(self, "Error", "Not connected to database")
            return
        
        query = self.query_edit.toPlainText().strip()
        if not query:
            QMessageBox.warning(self, "Error", "Query is empty")
            return
        
        try:
            cursor = self.current_connection.cursor()
            cursor.execute(query)
            
            # Check if query returns results
            if cursor.description:
                results = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description]
                
                self.results_table.setRowCount(len(results))
                self.results_table.setColumnCount(len(columns))
                self.results_table.setHorizontalHeaderLabels(columns)
                
                for i, row in enumerate(results):
                    for j, value in enumerate(row):
                        self.results_table.setItem(i, j, QTableWidgetItem(str(value)))
                
                self.results_table.resizeColumnsToContents()
                self.tabs.setCurrentIndex(1)  # Switch to Results tab
                
                QMessageBox.information(self, "Success", f"Query returned {len(results)} rows")
            else:
                self.current_connection.commit()
                QMessageBox.information(self, "Success", "Query executed successfully")
            
            cursor.close()
        
        except Exception as e:
            QMessageBox.critical(self, "Query Error", f"Failed to execute query:\n{str(e)}")
    
    def export_to_csv(self):
        """Export results to CSV"""
        if self.results_table.rowCount() == 0:
            QMessageBox.warning(self, "Error", "No results to export")
            return
        
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export to CSV", "", "CSV Files (*.csv);;All Files (*)"
        )
        
        if file_path:
            try:
                import csv
                
                with open(file_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    
                    # Write headers
                    headers = [self.results_table.horizontalHeaderItem(i).text()
                              for i in range(self.results_table.columnCount())]
                    writer.writerow(headers)
                    
                    # Write data
                    for row in range(self.results_table.rowCount()):
                        row_data = [self.results_table.item(row, col).text()
                                   for col in range(self.results_table.columnCount())]
                        writer.writerow(row_data)
                
                QMessageBox.information(self, "Success", f"Exported {self.results_table.rowCount()} rows to:\n{file_path}")
            
            except Exception as e:
                QMessageBox.critical(self, "Export Error", f"Failed to export:\n{str(e)}")
    
    def closeEvent(self, event):
        """Handle window close"""
        self.disconnect_database()
        event.accept()

# =============================================================================
# Main Entry Point
# =============================================================================

def main():
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    
    # Show splash screen
    splash = create_splash()
    if splash:
        splash.show()
        app.processEvents()
        
        # Add loading messages
        import time
        for msg in ["Starting...", "Loading modules...", "Initializing database..."]:
            splash.showMessage("\n\n\n\n\n\n\n" + msg, 
                             Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter, 
                             QColor(255, 255, 255))
            app.processEvents()
            time.sleep(0.3)
    
    # Create main window
    window = SQLManagerWindow()
    window.show()
    
    if splash:
        splash.finish(window)
    
    sys.exit(app.exec())

if __name__ == '__main__':
    main()
